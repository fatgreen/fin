$(function(){

            room = $("#room").value;
            username = $("#username").value;

            $("#open-room").on("click",function(){
               jump1();
            });
            $("#join-room").on("click",function(){
                jump1();
             });
        });

        function jump1(){
            url = "main.html?room="+$("#room").val()+"&username="+$("#username").val();//此處拼接內容
            window.location.href = url;
        }